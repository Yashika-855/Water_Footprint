from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[1]))

from src.io_utils import load_config, ensure_dirs

cfg = load_config()
ensure_dirs(cfg)

print("STEP 4: Soil preparation")
print("Do not choose soil variables until the paper's Table 1/supplement has been checked.")
print("If using HWSD instead of DSMW, record this deviation in metadata/DATA_SOURCES.csv.")
print("Save data/interim/soil_features.csv")
