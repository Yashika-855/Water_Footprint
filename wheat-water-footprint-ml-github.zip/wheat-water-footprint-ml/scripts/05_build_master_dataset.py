from pathlib import Path
import sys
import pandas as pd
sys.path.append(str(Path(__file__).resolve().parents[1]))

from src.io_utils import load_config, ensure_dirs
from src.integration import merge_location_tables, basic_quality_report

cfg = load_config()
ensure_dirs(cfg)

base = Path(cfg["paths"]["interim"])

wf_path = base / "wf_wheat_2010_2019.csv"
calendar_path = base / "wheat_crop_calendar.csv"
climate_path = base / "climate_features_2010_2019.csv"
soil_path = base / "soil_features.csv"

missing = [p for p in [wf_path, calendar_path, climate_path] if not p.exists()]
if missing:
    raise FileNotFoundError(
        "Missing required inputs: " + ", ".join(map(str, missing))
    )

wf = pd.read_csv(wf_path)
calendar = pd.read_csv(calendar_path)
climate = pd.read_csv(climate_path)
soil = pd.read_csv(soil_path) if soil_path.exists() else None

df = merge_location_tables(wf, calendar, climate, soil)
basic_quality_report(df)

out = Path(cfg["paths"]["processed"]) / "master_wheat_dataset.csv"
out.parent.mkdir(parents=True, exist_ok=True)
df.to_csv(out, index=False)

print("Saved:", out)
