from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[1]))

from src.io_utils import load_config, ensure_dirs

cfg = load_config()
ensure_dirs(cfg)

print("STEP 1: Water-footprint preparation")
print("1. Put the 4TU ZIP/NetCDF files in:", cfg["paths"]["raw_wf"])
print("2. Inspect variable names and coordinates.")
print("3. Confirm wheat exists in the selected-crops archive.")
print("4. Extract wheat and green/blue/unit WF fields.")
print("5. Aggregate the native ~0.0833 degree grid by 5x5 if required.")
print("6. Save data/interim/wf_wheat_2010_2019.csv")
