from pathlib import Path
import sys
import pandas as pd
sys.path.append(str(Path(__file__).resolve().parents[1]))

from src.io_utils import load_config, ensure_dirs
from src.features import select_k_features, save_feature_list

cfg = load_config()
ensure_dirs(cfg)

path = Path(cfg["paths"]["processed"]) / "master_wheat_dataset.csv"
df = pd.read_csv(path)

# The paper may define feature selection differently.
# Run separately for each target if reproducing target-specific selection.
target = "total_wf"

features, selector = select_k_features(df, target=target, k=20)
print("Selected features:")
for f in features:
    print(f)

save_feature_list(
    features,
    Path(cfg["paths"]["processed"]) / "selected_features.txt"
)
