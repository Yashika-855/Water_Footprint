from pathlib import Path
import sys
import pandas as pd
sys.path.append(str(Path(__file__).resolve().parents[1]))

from src.io_utils import load_config, ensure_dirs
from src.clustering import (
    prepare_cluster_matrix,
    kmeans_labels,
    hierarchical_labels,
)

cfg = load_config()
ensure_dirs(cfg)

df = pd.read_csv(Path(cfg["paths"]["processed"]) / "master_wheat_dataset.csv")
features = [
    x.strip()
    for x in Path(cfg["paths"]["processed"] / "selected_features.txt")
    .read_text(encoding="utf-8")
    .splitlines()
    if x.strip()
]

X_scaled, scaler = prepare_cluster_matrix(df, features)

_, km = kmeans_labels(
    X_scaled,
    k=cfg["clustering"]["k"],
    random_state=cfg["clustering"]["random_state"],
)

_, hc = hierarchical_labels(
    X_scaled,
    k=cfg["clustering"]["k"],
    linkage=cfg["clustering"]["hierarchical_linkage"],
)

out_km = df[["latitude", "longitude"]].copy()
out_km["cluster"] = km
out_km.to_csv(
    Path(cfg["paths"]["processed"]) / "cluster_assignments_kmeans.csv",
    index=False,
)

out_hc = df[["latitude", "longitude"]].copy()
out_hc["cluster"] = hc
out_hc.to_csv(
    Path(cfg["paths"]["processed"]) / "cluster_assignments_hierarchical.csv",
    index=False,
)

print("Clustering complete.")
