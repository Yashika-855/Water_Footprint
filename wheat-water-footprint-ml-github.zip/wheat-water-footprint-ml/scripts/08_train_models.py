from pathlib import Path
import sys
import pandas as pd
sys.path.append(str(Path(__file__).resolve().parents[1]))

from src.io_utils import load_config, ensure_dirs
from src.models import train_cluster_models, save_models

cfg = load_config()
ensure_dirs(cfg)

df = pd.read_csv(Path(cfg["paths"]["processed"]) / "master_wheat_dataset.csv")
clusters = pd.read_csv(
    Path(cfg["paths"]["processed"]) / "cluster_assignments_kmeans.csv"
)

df = df.merge(clusters, on=["latitude", "longitude"], how="inner")

features = [
    x.strip()
    for x in Path(cfg["paths"]["processed"] / "selected_features.txt")
    .read_text(encoding="utf-8")
    .splitlines()
    if x.strip()
]

for target in cfg["targets"]:
    models = train_cluster_models(
        df,
        features=features,
        target=target,
        cluster_col="cluster",
        random_state=cfg["project"]["seed"],
    )

    save_models(
        models,
        Path(cfg["paths"]["models"]) / "kmeans" / target
    )

    print(target, "clusters trained:", sorted(models))
