from pathlib import Path
import sys
import pandas as pd
sys.path.append(str(Path(__file__).resolve().parents[1]))

from src.io_utils import load_config, ensure_dirs
from src.models import train_cluster_models, predict_cluster_models
from src.evaluation import regression_metrics

cfg = load_config()
ensure_dirs(cfg)

df = pd.read_csv(Path(cfg["paths"]["processed"]) / "master_wheat_dataset.csv")
clusters = pd.read_csv(
    Path(cfg["paths"]["processed"]) / "cluster_assignments_kmeans.csv"
)
df = df.merge(clusters, on=["latitude", "longitude"], how="inner")

features = [
    x.strip()
    for x in Path(cfg["paths"]["processed"] / "selected_features.txt")
    .read_text(encoding="utf-8")
    .splitlines()
    if x.strip()
]

# NOTE:
# This is a baseline evaluation scaffold.
# Replace with the paper's exact train/test split before reporting results.
from sklearn.model_selection import train_test_split

train_idx, test_idx = train_test_split(
    df.index,
    test_size=0.2,
    random_state=cfg["project"]["seed"],
)

train = df.loc[train_idx].copy()
test = df.loc[test_idx].copy()

rows = []

for target in cfg["targets"]:
    models = train_cluster_models(
        train,
        features,
        target,
        cluster_col="cluster",
        random_state=cfg["project"]["seed"],
    )

    pred = predict_cluster_models(
        test,
        models,
        features,
        cluster_col="cluster",
    )

    valid = pred.dropna(subset=[target, "prediction"])
    metrics = regression_metrics(valid[target], valid["prediction"])
    metrics["target"] = target
    metrics["n_test"] = len(valid)
    rows.append(metrics)

    out = Path(cfg["paths"]["predictions"]) / f"{target}_predictions.csv"
    valid.to_csv(out, index=False)

metrics_df = pd.DataFrame(rows)
metrics_df.to_csv(
    Path(cfg["paths"]["metrics"]) / "kmeans_adaboost_metrics.csv",
    index=False,
)

print(metrics_df)
