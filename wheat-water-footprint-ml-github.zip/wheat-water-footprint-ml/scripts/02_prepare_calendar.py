from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[1]))

from src.io_utils import load_config, ensure_dirs

cfg = load_config()
ensure_dirs(cfg)

print("STEP 2: Crop-calendar preparation")
print("Place the four wheat calendar files in:", cfg["paths"]["raw_calendar"])
print("Required combinations: spring/winter x rainfed/irrigated.")
print("Inspect exact variable names before extracting planting/maturity DOY.")
print("Save data/interim/wheat_crop_calendar.csv")
