from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[1]))

from src.io_utils import load_config, ensure_dirs

cfg = load_config()
ensure_dirs(cfg)

print("STEP 3: Climate preparation")
print("First test ONLY precipitation (pr).")
print("Subset climate data to wheat locations before expensive processing.")
print("Then validate monthly aggregation and units.")
print("After validation, process hurs, sfcWind, tasmax, tasmin, rsds and ps.")
print("Save data/interim/climate_features_2010_2019.csv")
