from pathlib import Path
import numpy as np
import pandas as pd
import xarray as xr

CLIMATE_VARS = ["hurs", "sfcWind", "tasmax", "tasmin", "rsds", "ps", "pr"]

def inspect_units(path):
    ds = xr.open_dataset(path)
    for name in ds.data_vars:
        print(name, ds[name].attrs)
    return ds

def convert_common_units(ds):
    # Verify units before applying these conversions.
    for v in ["tasmax", "tasmin"]:
        if v in ds and ds[v].attrs.get("units", "").lower() in {"k", "kelvin"}:
            ds[v] = ds[v] - 273.15
            ds[v].attrs["units"] = "degC"

    if "pr" in ds:
        units = ds["pr"].attrs.get("units", "")
        if "kg" in units and "s-1" in units:
            ds["pr"] = ds["pr"] * 86400.0
            ds["pr"].attrs["units"] = "mm/day"

    if "ps" in ds and ds["ps"].attrs.get("units") == "Pa":
        ds["ps"] = ds["ps"] / 1000.0
        ds["ps"].attrs["units"] = "kPa"

    return ds

def monthly_aggregate(ds):
    reducers = {}
    if "pr" in ds:
        reducers["pr"] = ds["pr"].resample(time="MS").sum()
    for v in ["hurs", "sfcWind", "tasmax", "tasmin", "rsds", "ps"]:
        if v in ds:
            reducers[v] = ds[v].resample(time="MS").mean()
    return xr.Dataset(reducers)

def nearest_grid_lookup(ds, locations):
    # locations: DataFrame with latitude and longitude columns.
    lat = xr.DataArray(locations["latitude"].values, dims="location")
    lon = xr.DataArray(locations["longitude"].values, dims="location")
    out = ds.sel(lat=lat, lon=lon, method="nearest")
    return out
