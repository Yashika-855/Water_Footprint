import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import AgglomerativeClustering

def prepare_cluster_matrix(df, features):
    X = df[features].copy()
    X = X.fillna(X.median(numeric_only=True))
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    return X_scaled, scaler

def kmeans_labels(X_scaled, k=5, random_state=42):
    model = KMeans(n_clusters=k, random_state=random_state, n_init=20)
    return model, model.fit_predict(X_scaled)

def hierarchical_labels(X_scaled, k=5, linkage="ward"):
    model = AgglomerativeClustering(n_clusters=k, linkage=linkage)
    return model, model.fit_predict(X_scaled)
