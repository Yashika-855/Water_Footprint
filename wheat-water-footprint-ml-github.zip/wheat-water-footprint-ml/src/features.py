from pathlib import Path
import pandas as pd
from sklearn.feature_selection import SelectKBest, mutual_info_regression

TARGETS = ["green_wf", "blue_wf", "total_wf"]

def get_feature_columns(df):
    exclude = set(TARGETS + ["latitude", "longitude"])
    return [c for c in df.columns if c not in exclude and pd.api.types.is_numeric_dtype(df[c])]

def select_k_features(df, target, k=20, random_state=42):
    features = get_feature_columns(df)
    work = df[features + [target]].dropna()

    X = work[features]
    y = work[target]

    k = min(k, X.shape[1])
    selector = SelectKBest(score_func=mutual_info_regression, k=k)
    selector.fit(X, y)

    selected = list(X.columns[selector.get_support()])
    return selected, selector

def save_feature_list(features, path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text("\n".join(features), encoding="utf-8")
