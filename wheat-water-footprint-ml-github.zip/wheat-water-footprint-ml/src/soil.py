import geopandas as gpd
import pandas as pd

def read_soil_vector(path):
    return gpd.read_file(path)

def join_soil_to_locations(locations, soil_gdf):
    points = gpd.GeoDataFrame(
        locations.copy(),
        geometry=gpd.points_from_xy(locations.longitude, locations.latitude),
        crs="EPSG:4326",
    )
    soil_gdf = soil_gdf.to_crs(points.crs)
    joined = gpd.sjoin(points, soil_gdf, how="left", predicate="within")
    return pd.DataFrame(joined.drop(columns="geometry"))
