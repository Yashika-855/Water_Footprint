import pandas as pd

def merge_location_tables(wf, calendar, climate, soil=None):
    keys = ["latitude", "longitude"]

    df = wf.merge(calendar, on=keys, how="left")
    df = df.merge(climate, on=keys, how="left")

    if soil is not None:
        df = df.merge(soil, on=keys, how="left")

    return df

def basic_quality_report(df):
    print("Shape:", df.shape)
    print("\nMissing percentage:")
    print((df.isna().mean() * 100).sort_values(ascending=False).head(30))
