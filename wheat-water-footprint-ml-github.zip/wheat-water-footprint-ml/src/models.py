from pathlib import Path
import joblib
from sklearn.ensemble import AdaBoostRegressor
from sklearn.tree import DecisionTreeRegressor

def make_adaboost(random_state=42):
    base = DecisionTreeRegressor(max_depth=4, random_state=random_state)
    try:
        return AdaBoostRegressor(
            estimator=base,
            n_estimators=200,
            learning_rate=0.05,
            random_state=random_state,
        )
    except TypeError:
        return AdaBoostRegressor(
            base_estimator=base,
            n_estimators=200,
            learning_rate=0.05,
            random_state=random_state,
        )

def train_cluster_models(df, features, target, cluster_col="cluster", random_state=42):
    models = {}
    for cluster_id, group in df.groupby(cluster_col):
        train = group.dropna(subset=features + [target])
        if len(train) < 20:
            print(f"Skipping cluster {cluster_id}: only {len(train)} usable rows")
            continue
        model = make_adaboost(random_state)
        model.fit(train[features], train[target])
        models[int(cluster_id)] = model
    return models

def predict_cluster_models(df, models, features, cluster_col="cluster"):
    pred = df.copy()
    pred["prediction"] = float("nan")
    for cluster_id, model in models.items():
        mask = pred[cluster_col] == cluster_id
        if mask.any():
            pred.loc[mask, "prediction"] = model.predict(pred.loc[mask, features])
    return pred

def save_models(models, directory):
    Path(directory).mkdir(parents=True, exist_ok=True)
    for cluster_id, model in models.items():
        joblib.dump(model, Path(directory) / f"cluster_{cluster_id}.joblib")
