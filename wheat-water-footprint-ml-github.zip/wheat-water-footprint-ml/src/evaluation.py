import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

def mape_safe(y_true, y_pred, eps=1e-8):
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    denom = np.maximum(np.abs(y_true), eps)
    return np.mean(np.abs((y_true - y_pred) / denom)) * 100

def regression_metrics(y_true, y_pred):
    return {
        "MAE": mean_absolute_error(y_true, y_pred),
        "MSE": mean_squared_error(y_true, y_pred),
        "MAPE_percent": mape_safe(y_true, y_pred),
        "R2": r2_score(y_true, y_pred),
    }
