from pathlib import Path
import yaml
import pandas as pd

def load_config(path="config/config.yaml"):
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def ensure_dirs(cfg):
    for key in ["interim", "processed", "models", "metrics", "predictions", "figures"]:
        Path(cfg["paths"][key]).mkdir(parents=True, exist_ok=True)

def read_csv(path, **kwargs):
    return pd.read_csv(path, **kwargs)

def save_csv(df, path, index=False):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=index)
