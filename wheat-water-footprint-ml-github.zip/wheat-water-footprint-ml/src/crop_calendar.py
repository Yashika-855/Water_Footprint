from pathlib import Path
import pandas as pd
import xarray as xr

def inspect_calendar(path):
    ds = xr.open_dataset(path)
    print(ds)
    for name, var in ds.variables.items():
        print(name, var.dims, var.attrs)
    return ds

def calendar_to_dataframe(ds):
    # Adapt variable names after inspecting Zenodo files.
    return ds.to_dataframe().reset_index()

def combine_wheat_calendars(frames):
    return pd.concat(frames, ignore_index=True)
