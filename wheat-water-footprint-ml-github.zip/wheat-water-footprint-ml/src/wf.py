from pathlib import Path
import zipfile
import pandas as pd
import xarray as xr

def list_archive(zip_path):
    with zipfile.ZipFile(zip_path) as z:
        return z.namelist()

def open_netcdf(path):
    return xr.open_dataset(path)

def inspect_dataset(path):
    ds = xr.open_dataset(path)
    print(ds)
    print("\nVariables:")
    for name, var in ds.variables.items():
        print(name, var.dims, var.attrs)
    return ds

def aggregate_wf_grid(ds, factor=5):
    # IMPORTANT: This is a structural helper.
    # Adjust dimension names and aggregation rules after inspecting the provider NetCDF.
    lat_dim = "lat" if "lat" in ds.dims else "latitude"
    lon_dim = "lon" if "lon" in ds.dims else "longitude"
    return ds.coarsen({lat_dim: factor, lon_dim: factor}, boundary="trim").mean()
