# Data collection plan

## Phase A — small validation

1. Obtain WF data.
2. Obtain crop-calendar data.
3. Extract wheat only.
4. Join the two datasets.
5. Confirm coordinates, target values and calendar variables.

## Phase B — climate pilot

Use precipitation (`pr`) first.

1. Build wheat location list.
2. Request only the needed spatial area/cells.
3. Process 2010–2019.
4. Convert units after checking metadata.
5. Aggregate daily data to monthly features.
6. Apply the paper's crop-growth / seven-day rule.
7. Validate output.

Only after this works should the remaining six variables be processed.

## Phase C — remaining climate variables

Process:

- hurs
- sfcWind
- tasmax
- tasmin
- rsds
- ps

## Phase D — soil

Read the paper's Table 1 and supplementary material first.

Select the soil product and attributes that match the paper. If HWSD is used instead of DSMW, record it explicitly as a deviation.

## Disk strategy

Never keep unnecessary full-global copies after validating a subset.

Keep:

- raw source metadata
- downloaded files required for reproducibility
- processed wheat-location data
- scripts and checksums

Large source data should not be committed to GitHub.
