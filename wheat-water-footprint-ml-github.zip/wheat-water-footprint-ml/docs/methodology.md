# Methodology

## Problem

Traditional water-footprint estimation can require detailed climate, soil, crop and water-management information plus process-based simulation. Running such simulations globally is computationally expensive.

This project tests whether machine learning can learn the relationship between environmental conditions and wheat water footprint.

It also tests whether clustering environmental observations before regression is useful.

## Pipeline

### 1. Data integration

Combine:

- Global wheat water footprint
- Climate
- Soil
- Crop calendar

### 2. Spatial harmonization

Create a master grid based on the WF data aggregation described by the project guide.

### 3. Feature engineering

Create climate/crop/soil variables according to the paper.

### 4. Feature selection

Reduce approximately 102 candidate features to 20 after reproducing the paper's feature-selection method.

### 5. Clustering

Compare:

- K-means, K=5
- Hierarchical clustering, K=5

### 6. Regression

Train cluster-specific AdaBoost regressors.

### 7. Targets

Predict:

- green WF
- blue WF
- total WF

### 8. Evaluation

Report:

- MAE
- MSE
- MAPE
- R²

## Critical reproducibility note

The numbers 102 features, 20 selected features and K=5 should be treated as the intended paper workflow. The implementation must verify the paper's exact feature definitions, selection algorithm, clustering distance/linkage, AdaBoost hyperparameters and train/test protocol before claiming reproduction.
